
var sections = document.getElementsByClassName("section");
var configObject = {};
var headerNames = [];
var users = {};
var generateColours;

function highlight(toEnglarge) {
  headerNum = parseInt(toEnglarge.slice(-1)) + 1;
  if(headerNum == 7) {
    headerNum = 1;
  }
  document.getElementById("header-" + headerNum).classList.add("white");
  document.getElementById(toEnglarge).children[0].classList.add("enlarged");
}
function unhighlight(toEnglarge) {
  headerNum = parseInt(toEnglarge.slice(-1)) + 1;
  if(headerNum == 7) {
    headerNum = 1;
  }
  document.getElementById("header-" + headerNum).classList.remove("white");
  document.getElementById(toEnglarge).children[0].classList.remove("enlarged");
}
function fadeAllSections() {
  for(i = 0; i < 6; i++) {
    sections.item(i).classList.remove("visible");
  }
}
function getRandomColor() { //Generates a random colour in hex
  var letters = '0123456789ABCDEF';
  var color = '#';
  /*color += letters[Math.floor(Math.random() * 8)];*/
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  if(color == "#FFFFFF") { //If the colour is white, make it black
    color = "#000000";
  }
  return color;
}

function sectionClick(id) {
  $.get("write.php?c=" + (parseInt(id) + 1)); //Write to file which section we are currently on so the client can update
  if(document.getElementById("brand-wheel").classList.contains("small")) {
    sections.item(id).classList.add("visible");
  } else {
    document.getElementById("brand-wheel").classList.add("small");
    setTimeout(function() {sections.item(id).classList.add("visible");}, 1500);
  }
}

function large() {
  if(document.getElementById("brand-wheel").classList.contains("small")) {
    document.getElementById("brand-wheel").classList.remove("small");
    fadeAllSections();
    $.get("write.php?wait=wait");
  } else {
    document.getElementById("brand-wheel").classList.add("small");

  }
}

function Start() {
  $('#center-div').fadeOut(1000); //Fade out the qr code for 1 second
  setTimeout(function() {
    $('#fill').fadeOut(1000); //Fade out the white fill for 1 second after 1.25 seconds
  }, 1250);
}

function Update() {
  $('.section').each(function() { //For each section
    var container = $(this);
    var toGet = "read.php?file=" + container.attr("id"); //The file name of the section is the sections id
    $.get(toGet, function(content) { //Get the current text using read.php
      var new_count = 0;

      var old_count = container.children('ul').children('li').length; //How many list objects were there before
      var text = content.replace("\n", "").split("<br />"); //Split the object into an array based on the new lines
      container.children('ul').text(''); //Empty the ul
      var textArray = []
      Object.keys(text).forEach(function(key) { //For each text object in the array
        if(text[key] != "" && text[key] != "\n" && !textArray.includes(text[key].split("[ID]")[0])) { //If it has not been used before and is not blank
          textArray.push(text[key].split("[ID]")[0]); //Add it to the used before array
          container.children('ul').append("<li>"+text[key].split("[ID]")[0]+"</li>"); //Create the list object containing the text
          var newli = container.children('ul').children('li:last');
          if(new_count < old_count && generateColours) { //If it isn't new and we are generating colours
            if(users[text[key].split("[ID]")[1]]) { 
              newli.css("color", users[text[key].split("[ID]")[1]]); //Apply the colour if it exists
            } else {
              users[text[key].split("[ID]")[1]] = getRandomColor(); //Otherwise generate a new random colour and assign the user to it
              newli.css("color", users[text[key].split("[ID]")[1]]); 
            }
          }
          new_count = new_count + 1; //Add one to the new count so we know how many there are now
        }
      });
      var toAnimate = new_count - old_count; //Calculate how many new entries have been added
      if(toAnimate > 0) { //If there are new entries
        container.children('ul').children('li').slice(0-toAnimate).addClass("big"); //Add the big class to the bottom x amount (num of new entries)
        container.children('ul').animate({
        scrollTop: container.children('ul').get(0).scrollHeight}, 1000); //Automatically scroll to the bottom of the ul
      }
    });
  });
}

$.get("read.php?config=config", function(config) { //Read the config.json file



  configObject = JSON.parse(config); //Convert the file from a string to an object
  headerNames = configObject["HEADER-NAMES"];
  generateColours = configObject["GENERATE-COLOURS"];


  var urlCode = configObject["URL"];

  if(configObject["SHOW-QR"] == false) {
    $('#fill').fadeOut(0); //Fade out the qr code if it should not be shown
  } else {
    $('#qr-text').text('Scan the QR code or visit: ' + urlCode);
    $('#qr-code').attr('src','https://api.qrserver.com/v1/create-qr-code/?size=1000x1000&data='+urlCode); //Use the QR code API to display a QR code based off the config

    $("#wheel-center-text").text(configObject["CENTRE"]);
    if(configObject["SHOW-VIVID-BRANDING"] == false) {
      $("#logo").fadeOut(0);
    }
  }

  for(h = 0; h < headerNames.length; h++) { //For each header

  	document.getElementById("header-"+(h+1)).children[0].innerHTML = headerNames[h]; //Set the header name on the wheel
  	if(h < 6) {
  		document.getElementById("sec"+(h+1)).children[0].innerHTML = headerNames[h]; //Set the header name on the section titles
  	}
  }

  document.getElementById("header-1").onclick = function() { sectionClick(0); }; //Apply the section click function to each of the headers so when they are clicked we can animate
  document.getElementById("header-2").onclick = function() { sectionClick(1); };
  document.getElementById("header-3").onclick = function() { sectionClick(2); };
  document.getElementById("header-4").onclick = function() { sectionClick(3); };
  document.getElementById("header-5").onclick = function() { sectionClick(4); };
  document.getElementById("header-6").onclick = function() { sectionClick(5); };

  $.get("write.php?reset=reset"); //Reset the current data

  Update(); 

  setInterval(function() {Update();}, 1000); //Call the Update function every second

});
