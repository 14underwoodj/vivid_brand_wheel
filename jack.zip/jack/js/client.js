
var configObject = {};
var headerNames = [];
var messages = [];
var currentSecID;
var count = 0;
var idleText;
var uniqueID = "";

function Send() {
  var text = document.getElementById('text').value;
  if(text == "" || text == " ") { //Prevent blank input
    return;
  }
  text = text.replace("<script>", "(Trying to remotely execute scripts is forbidden, nice try)"); //Stop people injecting code or breaking the scripts
  text = text.replace("\\", " backslash ");
  text = text.replace("&", "and");
  text = text.replace(">", "right arrow");
  text = text.replace("<", "left arrow");
  text = text.replace("#", "hashtag");
  text = text.replace("'", "\\'");
  text = text.replace('"', '\\"');
  text = text.charAt(0).toUpperCase() + text.substr(1); //Make the first letter captital (test -> Test)
  $.get("write.php?sec="+currentSecID+"&text="+text+"&id="+uniqueID); //Write the text to file using write.php
  $('#text').val(""); //Reset the text to nothing after sending
  $('#popup-text').text(messages[Math.floor(Math.random() * messages.length)]);
  $('#popup-text').fadeIn(200);
  setTimeout(function() {
    $('#popup-text').fadeOut(500);
  }, 800);
}

function Update() {
  $.get("read.php", function(content) {
    if(parseInt(content) == 0) { //If current = 0 then we are idle
      $("#title").text(idleText);
      if(count == 0) { 
        $("#text").fadeOut(0); //We have just opened the app so fade out instantly
        $("#add").fadeOut(0);
      } else {
        $("#text").fadeOut(1000);
        $("#add").fadeOut(1000);
      }
    } else {
      $("#text").fadeIn(1000); //current != 0 so fade back in again
      $("#add").fadeIn(1000);
      currentSecID = parseInt(content);
      $("#title").text(headerNames[parseInt(content) - 1]);
    }
    count = 1;
    Update(); //Run the Update function again once we have finished the current Update
  });
}

$.get("read.php?config=config", function(config) {

  if(sessionStorage.getItem("id") === null) {
    uniqueID = "[ID]" + btoa(Math.random());
    sessionStorage.setItem("id", uniqueID);
  } else {
    uniqueID = sessionStorage.getItem("id");
  }

   //Generate a GUID by taking a random number and converting it to Base64 because it looks cool

  configObject = JSON.parse(config);
  headerNames = configObject["HEADER-NAMES"];
  idleText = configObject["IDLE-TEXT"]; //The text to show when no header is selected
  messages = configObject["MESSAGES"];
  if(configObject["SHOW-VIVID-BRANDING"] == false) {
    $("#logo").fadeOut(0);
  }
  if(configObject["SHOW-PARTICLES"] == false) {
    $("#particles-js").fadeOut(0);
  }

  $('#popup-text').fadeOut(0);
  
  document.getElementById('text').onkeypress = function(e) { //If someone types a key in the text field
      var event = e || window.event;
      var charCode = event.which || event.keyCode;

      if ( charCode == '13' ) { //If we press enter send the message
        Send();
        return false;
      }
  }

  Update();

});
