<?php
$sec = $_GET["file"];
$config = $_GET["config"];

$sec = str_replace(array('.', '/'), '', $sec);

if($config) {
  $fh = fopen("config.json", 'r');
  echo fread($fh, 25000);
} else {
  if($sec) {
    $fh = fopen("data/".$sec.".txt", 'r');
  } else {
    $fh = fopen("data/current.txt", 'r');
  }

  $pageText = fread($fh, 25000);
  echo nl2br($pageText);
}
?>
