<?php
$c = $_GET["c"];
$reset = $_GET["reset"];
$wait = $_GET["wait"];
if($reset) {
  $f = fopen("data/current.txt", "w");
  fwrite($f, "0");
  fclose($f);
  for ($x = 1; $x <= 6; $x++) {
    $f = fopen("data/sec".$x.".txt", "w");
    fwrite($f, "");
    fclose($f);
  }
} elseif($wait) {
  $f = fopen("data/current.txt", "w");
  fwrite($f, "0");
  fclose($f);
} elseif($c) {
  $f = fopen("data/current.txt", "w");
  fwrite($f, $c);
  fclose($f);
} else {
  $sec = $_GET["sec"];
  $sec = str_replace(array('.', '/'), '', $sec);
  $f = fopen("data/sec".$sec.".txt", "a");
  fwrite($f, $_GET["text"].$_GET["id"]."\n");
  fclose($f);
}

?>
